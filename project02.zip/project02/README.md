# Analyzing 10Gb of Yelp Reviews Data
## Overview
We will analyze a subset of Yelp's business, reviews and user data. This dataset comes to us from [Kaggle](https://www.kaggle.com/yelp-dataset/yelp-dataset) although we have taken steps to pull this data into a publis s3 bucket: 
`s3://sta9760-spark-project02-datasets/yelp_academic_dataset_business.json`
`s3://sta9760-spark-project02-datasets/yelp_academic_dataset_review.json`
`s3://sta9760-spark-project02-datasets/yelp_academic_dataset_user.json`

## Cluster and Notebook Configs

![cluster_configuration](C:\Users\xinyue\Desktop\Baruch Class\CIS 9760\project02\assets\cluster_configuration.PNG)



![notebook_configuration](C:\Users\xinyue\Desktop\Baruch Class\CIS 9760\project02\assets\notebook_configuration.PNG)



